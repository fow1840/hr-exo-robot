#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "proxsuite::instructionset" for configuration "Release"
set_property(TARGET proxsuite::instructionset APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(proxsuite::instructionset PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_RELEASE ""
  IMPORTED_LOCATION_RELEASE "${PACKAGE_PREFIX_DIR}/lib/python3.10/site-packages/proxsuite/instructionset.cpython-310-x86_64-linux-gnu.so"
  IMPORTED_NO_SONAME_RELEASE "TRUE"
  )

list(APPEND _cmake_import_check_targets proxsuite::instructionset )
list(APPEND _cmake_import_check_files_for_proxsuite::instructionset "${PACKAGE_PREFIX_DIR}/lib/python3.10/site-packages/proxsuite/instructionset.cpython-310-x86_64-linux-gnu.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
